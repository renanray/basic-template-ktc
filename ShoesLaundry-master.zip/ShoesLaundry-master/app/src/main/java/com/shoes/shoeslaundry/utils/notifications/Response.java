package com.shoes.shoeslaundry.utils.notifications;

public class Response {

    private String success;
}
